$(function() {
    hljs.initHighlightingOnLoad();
});
